using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
string? mode=null;
mode ??= "safe";
Console.WriteLine(mode);

