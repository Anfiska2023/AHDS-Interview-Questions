using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
var a=new int[]{1};
var b=a;b[0]=7;
Console.WriteLine(a[0]);

