using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
object x=12;
try { long y=(long)x; }
catch (InvalidCastException) { Console.WriteLine("type mismatch"); }

