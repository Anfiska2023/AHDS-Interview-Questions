using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
var original=new Packet(new int[]{1});
var copy=original with { };copy.Data[0]=9;
Console.WriteLine(original.Data[0]);

record Packet(int[] Data);
