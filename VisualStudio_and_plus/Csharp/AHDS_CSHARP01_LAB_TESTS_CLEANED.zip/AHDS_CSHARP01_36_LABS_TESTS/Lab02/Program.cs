using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
int value = -1;
Console.WriteLine(value >> 1);
Console.WriteLine(value >>> 1);

