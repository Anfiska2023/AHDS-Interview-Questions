using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
string a=new string(new[]{'a','b'});
string b=new string(new[]{'a','b'});
Console.WriteLine(a==b);
Console.WriteLine(object.ReferenceEquals(a,b));

