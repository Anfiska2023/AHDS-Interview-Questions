using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
double value=1.25;
Console.WriteLine(value.ToString("R",CultureInfo.InvariantCulture));

