using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
int raw=300;
Console.WriteLine(raw is >= 0 and <= 255);
if(raw is >=0 and <=255) Console.WriteLine((byte)raw);

