using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
double x=double.NaN;
Console.WriteLine(x is > 0 and < 5);
Console.WriteLine(double.IsNaN(x));

