using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
int[,] rect=new int[2,3];
int[][] jag={new int[2],new int[5]};
Console.WriteLine($"{rect.Length}/{jag[1].Length}");

