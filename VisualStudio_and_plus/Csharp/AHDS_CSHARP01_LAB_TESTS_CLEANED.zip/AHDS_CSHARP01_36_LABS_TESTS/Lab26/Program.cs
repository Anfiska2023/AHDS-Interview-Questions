using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
int state=3;
string label=state switch { 0=>"Idle",1=>"Run",2=>"Fault",_=>"Unknown"};
Console.WriteLine(label);

