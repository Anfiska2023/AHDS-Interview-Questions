using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
decimal money=0.1m+0.2m;
double meas=0.1+0.2;
Console.WriteLine(money);
Console.WriteLine(meas.ToString("R"));

