using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
var a=new Point(2);
var b=a; b.X=9;
Console.WriteLine($"{a.X}/{b.X}");

struct Point { public int X; public Point(int x)=>X=x; }
