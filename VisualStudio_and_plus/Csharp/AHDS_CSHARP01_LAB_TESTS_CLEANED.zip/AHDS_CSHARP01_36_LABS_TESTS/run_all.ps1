$ErrorActionPreference = 'Continue'
$failed = 0
foreach ($n in 1..36) {
    $id = '{0:D2}' -f $n
    $dir = Join-Path $PSScriptRoot "Lab$id"
    $project = Join-Path $dir "Lab$id.csproj"
    dotnet run --project $project -c Release -v quiet 2> (Join-Path $dir 'build-errors.txt') | Out-File (Join-Path $dir 'actual.txt') -Encoding utf8
    $status = $LASTEXITCODE
    if ($status -ne 0) { Write-Host "Lab$id COMPILE_OR_RUNTIME_FAILURE"; $failed++; continue }
    $actual = (Get-Content (Join-Path $dir 'actual.txt') -Raw).Trim()
    $expected = (Get-Content (Join-Path $dir 'expected.txt') -Raw).Trim()
    if ($actual -ceq $expected) { Write-Host "Lab$id PASS" } else { Write-Host "Lab$id OUTPUT_MISMATCH: '$actual' (expected '$expected')"; $failed++ }
}
Write-Host "Failed checks: $failed"
if ($failed -gt 0) { exit 1 }
