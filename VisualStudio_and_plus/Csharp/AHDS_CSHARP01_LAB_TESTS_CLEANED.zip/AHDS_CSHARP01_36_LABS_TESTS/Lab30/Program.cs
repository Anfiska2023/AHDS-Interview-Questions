using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
using var stream=new System.IO.MemoryStream();
stream.WriteByte(0xA5);
Console.WriteLine(stream.Length);

