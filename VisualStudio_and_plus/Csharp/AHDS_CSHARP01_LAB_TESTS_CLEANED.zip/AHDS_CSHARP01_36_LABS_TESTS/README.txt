AHDS CSHARP-01 — 36 Laboratory Checks

Status: Test inputs and expected outputs were prepared and reviewed, but they have NOT been compiled/executed in this environment because .NET SDK is unavailable.

Requirements: .NET SDK 8 or later; C# 11+ features (including >>>).
Windows PowerShell: powershell -ExecutionPolicy Bypass -File run_all.ps1
Linux/macOS: bash run_all.sh

Each LabXX has standalone Program.cs, .csproj, expected.txt. Compare results; investigate failing checks. Hardware integration is not covered by these checks.
