using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
string? name=null;
try { Console.WriteLine(name!.Length); }
catch (NullReferenceException) { Console.WriteLine("null at runtime"); }

