using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
byte a=250, b=10;
int sum=a+b;
Console.WriteLine(sum);
Console.WriteLine(unchecked((byte)sum));

