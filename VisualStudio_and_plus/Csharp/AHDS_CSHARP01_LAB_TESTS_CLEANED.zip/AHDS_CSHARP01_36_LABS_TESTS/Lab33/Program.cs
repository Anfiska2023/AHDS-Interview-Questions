using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
var args2=new[]{"--port","COM3"};
Console.WriteLine(args2.Length==2 ? args2[1] : "invalid");

