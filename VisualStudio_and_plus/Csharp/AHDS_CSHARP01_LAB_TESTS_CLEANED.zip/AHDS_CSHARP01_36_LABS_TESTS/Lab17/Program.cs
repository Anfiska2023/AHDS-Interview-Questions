using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
int n=5;object boxed=n;n=8;
Console.WriteLine(boxed);

