using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
byte reg=0xB5;
int high=(reg>>4)&0xF;
int low=reg&0xF;
Console.WriteLine($"{high:X} {low:X}");

