using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
var ok=double.TryParse("2.75",NumberStyles.Float,CultureInfo.InvariantCulture,out var v);
Console.WriteLine(ok ? v : double.NaN);

