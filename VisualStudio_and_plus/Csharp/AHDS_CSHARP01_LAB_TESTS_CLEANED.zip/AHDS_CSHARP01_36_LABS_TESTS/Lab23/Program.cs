using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
double voltage=2.6;
string state=voltage>=3.0 ? "HIGH" : "LOW";
Console.WriteLine(state);

