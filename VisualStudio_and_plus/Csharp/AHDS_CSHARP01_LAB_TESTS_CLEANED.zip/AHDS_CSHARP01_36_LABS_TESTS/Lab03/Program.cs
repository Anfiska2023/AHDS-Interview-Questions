using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
const uint Ready=1u<<0, Error=1u<<2;
uint status = Ready | Error;
Console.WriteLine((status & (Ready|Error)) == (Ready|Error));
Console.WriteLine((status & Error) != 0);

