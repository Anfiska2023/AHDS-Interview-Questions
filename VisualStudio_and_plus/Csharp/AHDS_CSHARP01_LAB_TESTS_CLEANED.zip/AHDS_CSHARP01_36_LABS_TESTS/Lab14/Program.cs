using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
var s=Status.Ready|Status.Error;
Console.WriteLine(s.HasFlag(Status.Error));

[Flags] enum Status { None=0, Ready=1, Error=2, Busy=4 }
