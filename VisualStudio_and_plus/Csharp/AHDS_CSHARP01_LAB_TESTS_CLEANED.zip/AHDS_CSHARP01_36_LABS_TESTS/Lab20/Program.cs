using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
int[] frame=new int[4];
int index=4;
Console.WriteLine(index>=0 && index<frame.Length);

