using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
int? reading=null;
Console.WriteLine(reading.HasValue);
Console.WriteLine(reading ?? -1);

