using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
(int Id,double Voltage) data=(4,3.3);
Console.WriteLine(data.Voltage);

