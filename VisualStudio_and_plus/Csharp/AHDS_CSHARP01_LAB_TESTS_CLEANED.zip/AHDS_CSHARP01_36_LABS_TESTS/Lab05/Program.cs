using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
double sample = double.NaN;
// Compare two runtime variables to demonstrate NaN semantics without CS1718.
double secondSample = sample;
Console.WriteLine(sample == secondSample);
Console.WriteLine(double.IsFinite(sample));

