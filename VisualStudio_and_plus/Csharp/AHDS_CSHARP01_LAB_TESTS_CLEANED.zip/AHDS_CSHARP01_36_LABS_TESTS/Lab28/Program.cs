using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
int[] values={1,2,3};
for(int i=0;i<values.Length;i++) values[i] *= 2;
foreach(var v in values) Console.WriteLine(v);

