using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
int tries=0;
do { tries++; } while(tries<1);
Console.WriteLine(tries);

