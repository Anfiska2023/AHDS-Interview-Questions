using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
byte lo=0x34, hi=0x12;
ushort value=(ushort)(lo | (hi << 8));
Console.WriteLine($"0x{value:X4}");

