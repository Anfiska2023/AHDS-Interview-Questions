using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
int code=2;
string msg=code switch {1=>"Ready",2=>"Busy",_=>"Fault"};
Console.WriteLine(msg);

