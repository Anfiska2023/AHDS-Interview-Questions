using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
double p=0.0, m=-0.0;
Console.WriteLine(p == m);
Console.WriteLine(1.0/p);
Console.WriteLine(1.0/m);

