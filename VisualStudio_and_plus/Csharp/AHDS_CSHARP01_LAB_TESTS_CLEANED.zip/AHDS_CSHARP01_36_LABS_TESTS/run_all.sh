#!/usr/bin/env bash
set -u
cd "$(dirname "$0")"
failed=0
for n in $(seq -w 1 36); do
  folder="Lab$n"
  printf '%s: ' "$folder"
  if dotnet run --project "$folder/Lab$n.csproj" -c Release -v quiet > "$folder/actual.txt" 2> "$folder/build-errors.txt"; then
    if diff -w -B "$folder/expected.txt" "$folder/actual.txt" >/dev/null; then echo PASS; else echo OUTPUT_MISMATCH; failed=$((failed+1)); fi
  else echo COMPILE_OR_RUNTIME_FAILURE; failed=$((failed+1)); fi
done
printf '\nFailed checks: %s\n' "$failed"
exit "$((failed>0))"
