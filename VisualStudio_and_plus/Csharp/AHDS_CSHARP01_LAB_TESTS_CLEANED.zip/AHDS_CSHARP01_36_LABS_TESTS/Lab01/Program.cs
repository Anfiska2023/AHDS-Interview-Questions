using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
int n = int.MaxValue;
try { Console.WriteLine(checked(n + 1)); }
catch (OverflowException) { Console.WriteLine("overflow"); }

