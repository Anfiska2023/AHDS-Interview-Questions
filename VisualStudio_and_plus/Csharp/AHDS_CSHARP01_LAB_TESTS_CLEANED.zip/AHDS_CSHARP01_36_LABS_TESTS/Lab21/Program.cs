using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
int samples=9, groups=2;
Console.WriteLine(samples/groups);
Console.WriteLine((double)samples/groups);

