using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
var m=(Mode)99;
Console.WriteLine(Enum.IsDefined(m));

enum Mode { Idle=0, Active=1 }
