using System;
using System.Globalization;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
string? text=null;
Console.WriteLine(text != null && text.Length>3);

