using System;
class Sensor {public int Id=17;}
class Program {static T Make<T>() where T : new()=>new T(); static void Main()=>Console.WriteLine(Make<Sensor>().Id);}
