using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Linq.Expressions;

Base x = new Derived();
Console.WriteLine(x.Read());
Console.WriteLine(x.Info());
class Base { public virtual int Read()=>1; public int Info()=>3; }
class Derived: Base { public override int Read()=>2; public new int Info()=>4; }
