using System;
class Program { static void Main(){int x=0;Action a=()=>x++;Action b=()=>x+=10; Action multicast=a+b;multicast();Console.WriteLine(x);}}
