AHDS CSHARP-02 — CODE VERIFICATION SUITE / ПРОВЕРКА КОДА

РУССКИЙ
1. Проверьте dotnet --version (требуется SDK .NET 8).
   https://dotnet.microsoft.com/download/dotnet/8.0
2. Распакуйте архив так, чтобы папки Lab01 ... Lab20 и RUN_ALL_TESTS.ps1 оказались внутри C:\AHDS_CSHARP02_CODE_VERIFICATION.
3. PowerShell:
   cd C:\AHDS_CSHARP02_CODE_VERIFICATION
   powershell -ExecutionPolicy Bypass -File .\RUN_ALL_TESTS.ps1
4. Пришлите AHDS_CSHARP02_Code_Verification_Results.txt.

ENGLISH
This package contains 12 earlier labs plus 8 supplementary technical examples. These are runnable checks, NOT individual certification of all 237 questions and answers. A clean PASS requires compilation and exact output match. Checks use .NET 8. Some conceptual claims require specification review and negative compilation tests beyond this package. Do not publish '237/237 code tests passed'.

FRANÇAIS
Ce paquet comprend 12 laboratoires déjà vérifiés et 8 exemples techniques supplémentaires. Il ne constitue PAS une certification individuelle des 237 questions-réponses. Exécutez le script PowerShell depuis le dossier extrait et transmettez le rapport.
