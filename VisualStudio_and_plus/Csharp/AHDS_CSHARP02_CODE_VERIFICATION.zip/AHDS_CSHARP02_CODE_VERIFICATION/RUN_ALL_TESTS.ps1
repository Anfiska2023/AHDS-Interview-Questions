﻿$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$report = Join-Path $root 'AHDS_CSHARP02_Code_Verification_Results.txt'
$pass = 0; $fail = 0
$lines = @('AHDS CSHARP-02 CODE VERIFICATION', ('Date: ' + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')), ('SDK: ' + ((& dotnet --version 2>&1) -join ' ')), 'Environment: Windows PowerShell / net8.0','Scope: 12 previously validated labs + 8 supplementary demonstrations','')
function Normalize([string]$value) { return (($value -replace "`r`n", "`n" -replace "`r", "`n").TrimEnd("`n", "`r", ' ', "`t")) }
foreach ($i in 1..20) {
    $name = 'Lab{0:D2}' -f $i
    $path = Join-Path $root $name
    $proj = Join-Path $path ($name + '.csproj')
    $expect = Join-Path $path 'expected.txt'
    $expectedText = Normalize ([System.IO.File]::ReadAllText($expect))
    $out = & dotnet run --project $proj --configuration Release --nologo 2>&1
    $exit = $LASTEXITCODE
    $actualText = Normalize (($out | ForEach-Object { $_.ToString() }) -join "`n")
    $matched = ($expectedText -ceq $actualText)
    $ok = ($exit -eq 0 -and $matched)
    if ($ok) {$pass++;$state='PASS'} else {$fail++;$state='FAIL'}
    Write-Host ($name + ': ' + $state)
    $lines += @('PROJECT: ' + $proj,'RESULT: ' + $state,'EXIT CODE: ' + $exit,'OUTPUT MATCH: ' + $matched,'EXPECTED: ' + $expectedText,'ACTUAL: ' + $actualText,'----------------------------------------')
}
$lines += 'SUMMARY: PASS=' + $pass + ' FAIL=' + $fail
[System.IO.File]::WriteAllLines($report,[string[]]$lines,[System.Text.UTF8Encoding]::new($false))
Write-Host ('SUMMARY: PASS=' + $pass + ' FAIL=' + $fail)
Write-Host ('Report: ' + $report)
if($fail -gt 0) { exit 1 } else { exit 0 }
