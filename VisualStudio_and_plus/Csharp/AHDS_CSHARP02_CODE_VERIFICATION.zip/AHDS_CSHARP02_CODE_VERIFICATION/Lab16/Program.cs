using System;
class Bus { public event Action? Changed; public void Raise()=>Changed?.Invoke(); }
class Program {static void Main(){var b=new Bus();int x=0;Action handler=()=>x++; b.Changed+=handler;b.Raise();b.Changed-=handler;b.Raise();Console.WriteLine(x);}}
