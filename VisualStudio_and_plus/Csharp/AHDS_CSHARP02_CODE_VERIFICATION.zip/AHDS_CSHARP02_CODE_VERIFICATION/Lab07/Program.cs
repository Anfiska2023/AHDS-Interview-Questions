using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Linq.Expressions;

Action<object> printer = o => Console.WriteLine(o);
Action<string> printText = printer;
printText("ok");
