using System;
record Payload(int[] Data);
class Program {static void Main(){var original=new Payload(new[]{1});var copy=original with{};copy.Data[0]=8;Console.WriteLine(original.Data[0]);}}
