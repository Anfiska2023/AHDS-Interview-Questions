using System;
class Box { public int Value; }
class Holder { public readonly Box Item = new(); }
class Program { static void Main(){var h=new Holder();h.Item.Value=7;Console.WriteLine(h.Item.Value);}}
