using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Linq.Expressions;

var data = new List<int> { 1 };
var model = new Holder(data);
model.Values.Add(2);
Console.WriteLine(model.Values.Count);
sealed class Holder(List<int> values)
{
    public readonly List<int> Values = values;
}
