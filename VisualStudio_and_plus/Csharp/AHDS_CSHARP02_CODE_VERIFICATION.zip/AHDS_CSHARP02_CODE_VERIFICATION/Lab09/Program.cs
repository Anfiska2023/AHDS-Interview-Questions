using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Linq.Expressions;

int x = 1;
Func<int> get = () => x;
x = 9;
Console.WriteLine(get());
