using System;
class Counter { public static int Shared; public void Increase()=>Shared++; }
class Program { static void Main(){Counter.Shared=0;new Counter().Increase();new Counter().Increase();Console.WriteLine(Counter.Shared);}}
