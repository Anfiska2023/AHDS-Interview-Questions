using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Linq.Expressions;

Action a = () => Console.Write("A");
a += () => throw new InvalidOperationException();
a += () => Console.Write("C");
try { a(); } catch (InvalidOperationException) { Console.Write("!"); }
