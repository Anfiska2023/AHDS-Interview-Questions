using System;
using System.Threading;
class State {public volatile bool Stop;}
class Program {static void Main(){var s=new State(); var t=new Thread(()=>{while(!s.Stop){Thread.Yield();} Console.WriteLine("stopped");});t.Start();s.Stop=true;t.Join();}}
