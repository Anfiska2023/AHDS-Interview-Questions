using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Linq.Expressions;

Expression<Func<int,bool>> expression = n => n > 5;
Console.WriteLine(expression.Body.NodeType);
