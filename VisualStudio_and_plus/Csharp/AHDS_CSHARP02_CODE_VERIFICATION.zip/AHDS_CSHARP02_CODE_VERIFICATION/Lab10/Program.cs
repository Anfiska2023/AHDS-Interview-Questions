using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Linq.Expressions;

Func<int,int> square = static x => x*x;
Console.WriteLine(square(4));
