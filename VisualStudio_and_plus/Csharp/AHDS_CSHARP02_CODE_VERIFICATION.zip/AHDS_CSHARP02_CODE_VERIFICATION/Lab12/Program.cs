using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Linq.Expressions;

bool ok = int.TryParse("not an integer", out int value);
Console.WriteLine($"{ok}:{value}");
