using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Linq.Expressions;

IProbe p = new Probe();
Console.WriteLine(p.Read());
interface IProbe { int Read(); }
sealed class Probe : IProbe { int IProbe.Read() => 42; }
