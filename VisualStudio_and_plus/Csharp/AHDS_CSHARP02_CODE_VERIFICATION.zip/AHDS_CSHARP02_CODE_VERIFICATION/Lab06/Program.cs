using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Linq.Expressions;

Console.WriteLine(Create<Reading>().Value);
static T Create<T>() where T : new() => new T();

class Reading { public int Value {get;set;} = 17; }
