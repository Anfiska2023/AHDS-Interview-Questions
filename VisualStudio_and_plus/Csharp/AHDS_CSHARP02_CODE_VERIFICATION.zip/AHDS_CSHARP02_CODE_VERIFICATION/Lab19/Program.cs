using System;
using System.Collections.Generic;
class Program {static void Main(){IEnumerable<string> names=new[]{"A"};IEnumerable<object> objects=names;Console.WriteLine(string.Join(",",objects));}}
