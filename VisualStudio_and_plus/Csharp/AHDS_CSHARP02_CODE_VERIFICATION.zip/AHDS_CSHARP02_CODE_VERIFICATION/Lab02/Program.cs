using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Linq.Expressions;

int count = 0;
Parallel.For(0, 1000, _ => Interlocked.Increment(ref count));
Console.WriteLine(count);
