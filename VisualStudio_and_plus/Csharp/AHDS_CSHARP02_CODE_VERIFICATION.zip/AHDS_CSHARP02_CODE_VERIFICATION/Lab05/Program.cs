using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Linq.Expressions;

var a = new Sample(new List<int>{1});
var b = a with { };
b.Points.Add(2);
Console.WriteLine(a.Points.Count);
record Sample(List<int> Points);
